<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $data = Employee::get();  
        
        return view('emplyee.employee_index', compact('data'));
    }
    


    // method  use for filter by username and email

    public function filterByEmployeePage(Request $request)
    {
        
        $data = Employee::orderBy($request->sort, 'asc')->get();    
        
        return view('emplyee.employee_index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function addEmployeePage()
    {
        //
        return view('emplyee.add_employee');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storeEmployeePage(Request $request)
    {
        //

        $request->validate([
            'username' => 'required',
            'email' => 'required|string|email|max:255|unique:employees',
            'phone_no' => 'required|integer',
            'gender' => 'required'
            ]);

            $company = new Employee();
            $company->username = $request->username;
            $company->email = $request->email;
            $company->phone = $request->phone_no;
            $company->gender = $request->gender;
            $company->save();

            return redirect()->route('employee_index')
            ->with('success','employee has been created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
      
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editEmployeePage($id)
    {
        //
        $getData = Employee::find($id);
        return view('emplyee.edit_employee', compact('getData'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateEmployeePage(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'email' => 'required|string|email|max:255|unique:employees,email, '.$request->id,
            'phone_no' => 'required|integer',
            'gender' => 'required'

            ]);
        

            $find = Employee::where('id',$request->id)->first();
            
            $find->username = $request->username;
            $find->email = $request->email;
            $find->phone = $request->phone_no;        
            $find->gender = $request->gender;      
            $find->update();
            return redirect()->route('employee_index')
            ->with('success','employee has been update successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteEmployeePage(Request $request, $id)
    {
        //dd
        
        $emply = Employee::find($id);
            
            $result = $emply->delete();
            if ($result) {
                return redirect()->route('employee_index')
            ->with('success','Employee Data Delete Successfully..');
            } else {
                return redirect()->back()->withSuccess('Something Wrong');
            }
    }
}
