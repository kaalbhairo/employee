<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Employee list</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
    
</head>

<body>
    
    <div class="container mt-2">
        <div class="row">
            <div class="pull-left">
                <h2>Employee Manage</h2>
            </div>
            <div class="col-lg-12 margin-tb">
                <div class="pull-right mb-2">
                    <a class="btn btn-success" href="<?php echo e(route('add_employee_page')); ?>"> Create Employee</a>
                </div>
            </div>
        </div>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        
      
        <table class="table table-bordered" id="tableEmp">
            <div class="col-xs-4 col-sm-4 col-md-4">
                <div class="form-group">
                    <strong>Filter By:</strong>
                    <form id="filterForm" action="<?php echo e(route('filter_by_employee_page')); ?>" method="GET">
                        <select id="sort" name="sort" onchange="submitForm()" class="form-select form-control">
                            <option value="">filter by</option>
                            <option value="username">username</option>
                            <option value="email">email</option>
                        </select>
                        
                        </form>
                            </div>
                </div>
            <thead>
            
            <tr>
                <th>S.No</th>
                <th>Employee Name</th>
                <th>Employee Email</th>
                <th>Employee Phone</th>
                <th>Employee Gender</th>
                <th width="280px">Action</th>
            </tr>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($employee->username); ?></td>
                    <td><?php echo e($employee->email); ?></td>
                    <td><?php echo e($employee->phone); ?></td>
                    <td><?php echo e($employee->gender); ?></td>
                    <td>                        
                        <form action="<?php echo e(route('delete_employee',$employee->id)); ?>" method="POST">
                        <a class="btn btn-primary" href="<?php echo e(route('edit_employee_page',$employee->id)); ?>"><i class="fa fa-pencil"></i> &nbsp;Edit</a>
                                                        
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger "><i class="fa fa-trash"></i>&nbsp; Delete</button>
                        </form>
                    </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        
        
        
        
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
    
        <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
        <script>
            $(document).ready(function() {
                $('#tableEmp').DataTable();

                
            });
            
            </script>
            
            <script>
                function submitForm() {
                    var filterValue = document.getElementById('sort').value;
                    var form = document.getElementById('filterForm');
                    var actionUrl = form.getAttribute('action');
                    var updatedActionUrl = actionUrl + '?sort=' + filterValue;
                    form.setAttribute('action', updatedActionUrl);
                    form.submit();
                }
            </script>
            
            
</body>

</html>
<?php /**PATH /var/www/html/employee_app/resources/views/emplyee/employee_index.blade.php ENDPATH**/ ?>